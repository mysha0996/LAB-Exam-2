<?php 

	$name = $pass = $cpass = $email = $uname = $gender ="";
	$errname = $errpass = $errcpass = $erremail = $erruname = $errgender = "";
	$iserror = 0;

	if(isset($_POST['submit'])){

		
		if(isset($_POST['name'])){
			$name = trim($_POST['name']);
		}
		else
		{
			$errname = "Name cannot be empty";
			$iserror = 1 ;
		}

		if(isset($_POST['pass'])){
			$pass = trim($_POST['pass']);
		}
		else
		{
			$errpass = "Password cannot be empty";
			$iserror = 1 ;
		}

		if(isset($_POST['cpass']))
		{
			$cpass = trim($_POST['cpass']);
			if($pass != $cpass)
			{
				$errcpass = "Password Must match";
				$iserror = 1 ;
			}
		}
		
		else
		{
			$errcpass = "Password cannot be empty";
			$iserror = 1 ;
		}
		
		if(isset($_POST['email'])){
			$email = trim($_POST['email']);
		}
		else
		{
			$erremail = "Email cannot be empty";
			$iserror = 1 ;
		}


		if(isset($_POST['gender']))
		{
			$gender = $_POST['gender'];
		}
		else
		{
			$errtype = "Gender cannot be empty";
			$iserror = 1 ;
		}

		if($iserror == 0){
			$db = mysqli_connect("localhost","root","","registration");

			$query = "insert into user values('$name',$email,$uname,'$pass','$dob''$gender')" ;

			mysqli_query($db , $query);  

			header("Location:login.php");  
		}

	}

?>
<!DOCTYPE html>
<html>
	<head>
		<title>Registration</title>
	</head>
	<body>
		<center>
			<fieldset>
				<legend><b>REGISTRATION</b></legend>
					<form method="post" action="registration.php">
						<br/>
						<table width="100%" cellpadding="0" cellspacing="0">
						<tr>
						<td>Name</td>
						<td>:</td>
						<td><input name="name" type="text" value = "<?php echo $name ?>"></td>
						<td></td>
						</tr>		
						<tr><td colspan="4"><hr/></td></tr>
						<tr>
						<td>Email</td>
						<td>:</td>
						<td>
						<input name="email" type="text" value = "<?php echo $email ?>">
					<abbr title="hint: sample@example.com"><b>i</b></abbr>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>User Name</td>
				<td>:</td>
				<td><input name="userName" type="text" value = "<?php echo $uname ?>"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Password</td>
				<td>:</td>
				<td><input name="password" type="password" value = "<?php echo $pass ?>"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Confirm Password</td>
				<td>:</td>
				<td><input name="confirmPassword" type="password" value = "<?php echo $cpass ?>"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Gender</legend>    
						<input name="gender" type="radio" value=0/>Male
						<input name="gender" type="radio" value=1>Female
						<input name="gender" type="radio" value=2>Other
					</fieldset>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Date of Birth</legend>    
						<input type="text" size="2"  />/
						<input type="text" size="2" />/
						<input type="text" size="4" />
						<font size="2"><i>(dd/mm/yyyy)</i></font>
					</fieldset>
				</td>
				<td></td>
			</tr>
		</table>
		<hr/>
		<input type="submit" name="submit"  value="Submit">
		<input type="reset">
	</form>
</fieldset>